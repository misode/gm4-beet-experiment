# Credits

## Creator
- [Sparks](https://twitter.com/SparksTheGamer)

## Updated by
- Federick90
- [BluePsychoRanger](https://twitter.com/BluPsychoRanger)

## Textures by
- [kyrkis](http://discordapp.com/users/287287322360414218)

## Icon Design
- [Sparks](https://twitter.com/SparksTheGamer)
